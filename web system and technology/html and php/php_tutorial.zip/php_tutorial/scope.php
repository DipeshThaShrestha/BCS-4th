<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3 style='text-align:center;'>variable scope</h3>
    <?php
    echo "<p>variable with global scope</p>";
    $a = 10; // $a is global variable
    function check()
    {
        echo "Inside check(), the value of a= ".$a."<br>";
    }
    check();
    echo "<p> outside the function, the value of a= ".$a."</p>";

    echo "<p> checking local scope of variable</p>";
    function display()
    {
        //$name has local scope inside display()
        $name = "sunway";
        echo "<p>Hello! ".$name."</p>";
    }
    display();
    echo "<p>Hello ".$name." Iam calling from outside the display()</p>";

    echo "<p>Accessing global variable in a function</p>";
    $a = 10;
    $b = 20;
    function sum()
    {
        global $a,$b;
        $b = $a+$b;
    }
    sum();
    echo "<p> The value of b= ".$b."</p>";
    // echo var_dump($GLOBALS);
    $x = 10;
    $y = 40;
    function sum_again()
    {
        $GLOBALS['y'] = $GLOBALS['x']+$GLOBALS['y'];
    }
    sum_again();
    echo "<p>The value of y= ".$y."</p>";
    // echo var_dump($GLOBALS);
    echo "<p>static variable</p>";

    function testStatic()
    {
        static $i = 10;
        echo $i."<br>";
        $i++; //11
    }
    testStatic();
    testStatic();
    testStatic();

    function testNonstatic()
    {
        $k = 50;
        echo $k."<br>";
        $k++;
    }
    testNonstatic();
    testNonstatic();
    testNonstatic();
    ?>
</body>
</html>