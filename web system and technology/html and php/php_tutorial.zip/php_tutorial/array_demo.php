<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array in php</title>
</head>
<body>
    <h2 style='text-align:center;'>Array in php</h2>
    <?php
    $name = array("Ram","shyam","sita","Gita");
    echo $name[0]." ".$name[1]." ".$name[2]." ".$name[3]."<br>";
    echo "length of array is: ".count($name)."<br>"; 
    $cars = array("BMW","TOYOTA","TESLA");
    $len = count($cars);
    echo "<p>The elements of array are: </p>";
    for($i=0;$i<$len;$i++)
    {
        echo $cars[$i]."<br>";
    }
    $record = array("name"=>"sunway","age"=>10,"address"=>"MaitiDevi","type"=>"college");
    // echo var_dump($record);
    foreach($record as $k=>$v)
    {
        echo $k.":",$v."<br>";
    }

    $m_arr = array(
        array("A",10,20),
        array("B",30,40),
        array("C",50,60)
    );

    // echo var_dump($m_arr);
    // echo var_dump($m_arr[0][0]);
    echo "<hr>";
    for($i=0;$i<3;$i++)
    {
        for($j=0;$j<3;$j++)
        {
            echo $m_arr[$i][$j]."   ";
        }
        echo "<br>";
    }
    echo "<br>";

    ?>
</body>
</html>