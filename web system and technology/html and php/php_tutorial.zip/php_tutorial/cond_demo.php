<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    echo "<p>if conditional statement </p>";
    $num=4;
    if($num%2==0) 
       echo $num." is even "."<br>";


    echo "<p>if .. else statement</p>";
    $num=5;
    if($num%2==0) 
       echo $num." is even "."<br>";
    else
      echo $num." is odd "."<br>";
    
 

    ?>
</body>
</html>