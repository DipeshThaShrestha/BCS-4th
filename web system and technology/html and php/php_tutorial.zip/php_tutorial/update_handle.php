<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form handling</title>
</head>
<body>    
    <?php
    $server = "localhost";
    $user = "root";
    $pwd = "";
    $db = "sunway";
    $conn = new mysqli($server,$user,$pwd,$db);
    $name=$age=$marks = "";
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $marks = $_POST['marks'];
        $id = $_POST['id'];
        if($conn->connect_error)
        {
            die("connection aborted");
        }
        else
        {
            // $sql = "INSERT INTO student(name,age,marks)values('$name'".",".$age.",".$marks.")";
            $sql = "UPDATE student SET name='$name',age=$age,marks=$marks where id=$id";
            // echo $sql;
            if($conn->query($sql)===TRUE)
            {
                header('location:student_list.php');
            }
            else
            {
                echo "<p>Error!!</p>";
            }
        }

    }
    ?>
</body>
</html>