<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>loop in php</title>
</head>
<body>
    <h3 style="text-align:center;">Loop in php</h3>
    <?php
    $i=5;
    while($i>10)
    {
        echo "<p>while loop is entry controlled</p>";
        $i++;
    }

    do{
        echo "<p> do .. while loop is exit controlled</p>";
        $i++;
    }while($i>10);

    for($i=1;$i<11;$i++)
    {
        echo $i."<br>";
    }

    $name = array("Ram","Shyam","Sita","Gita");
    foreach($name as $i)
    {
        echo $i."<br>";
    }
    $sum=0;
    for($i=1;$i<11;$i++)
    {
        if($i==6)
          break;
        else
          $sum +=$i;  
    }
    echo "Total sum= ".$sum."<br>";

    $sum=0;
    for($i=1;$i<11;$i++)
    {
        if($i==2 or $i==4)
          continue;
        else
          $sum +=$i;  
    }
    echo "Total sum= ".$sum."<br>";

    ?>
</body>
</html>