<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $server = "localhost";
        $user = "root";
        $pwd = "";
        $db = "sunway";
        $conn = new mysqli($server,$user,$pwd,$db);
        if($conn->connect_error)
        {
            die("connection aborted");
        }
        else
        {
           $id =  $_GET['id'];
           $sql = "DELETE FROM student where id=$id";
           if($conn->query($sql)===TRUE)
           {
               header("location:student_list.php");
           }
           else
           {
               echo "<p style='color:red;font-weight:bold;'>Error deleting record with id = $id</p>";
           }
        }
    ?>
</body>
</html>