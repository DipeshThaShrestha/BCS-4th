<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .error{
            color:red;
        }
    </style>
</head>
<body>
    <?php
    // echo var_dump($_POST);
    $name_err=$email_err=$website_err=$gender_err="";
    $name=$email=$website=$comment=$gender="";
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        if(empty($_POST['name']))
        {
            $name_err="Name is required";
        }
        else
        {
            $name = $_POST['name'];
        }
        if(empty($_POST['email']))
        {
            $email_err="Email is required";
        }
        else
        {
            $email = $_POST['email'];
        }
        if(empty($_POST['website']))
        {
            $website_err="website is required";
        }
        else
        {
            $website = $_POST['website'];
        }
        if(empty($_POST['gender']))
        {
            $gender_err="gender is required";
        }
        else
        {
            $gender = $_POST['gender'];
        }
    }
    ?>

     <h3>user registration form</h3>
    <p style='color:blue;font-weight:bold;'>* indicates required fields</p>
    <form action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
    Name: <input type="text" name="name">
    <span class="error">* <?php echo $name_err; ?></span>
    <br> <br>
    E-mail: <input type="text" name="email">
    <span class="error">*<?php echo $email_err; ?></span>
    <br><br>
    Website: <input type="text" name="website">
    <span class="error">*<?php echo $website_err; ?></span>
    <br><br>
    Comment: <textarea name="comment" rows="5" cols="40"></textarea><br> <br>
    Gender:
    <input type="radio" name="gender" value="female">Female
    <input type="radio" name="gender" value="male">Male
    <input type="radio" name="gender" value="other">Other 
    <span class="error">*<?php echo $gender_err; ?></span>
    <br> <br>
    <input type="submit">
    </form>
</body>
</html>