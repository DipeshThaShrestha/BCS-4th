<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $server = "localhost";
        $user = "root";
        $pwd = "";
        $db = "sunway";
        $conn = new mysqli($server,$user,$pwd,$db);
        $name = $age=$marks="";
        if($conn->connect_error)
        {
            die("connection aborted");
        }
        else
        {
           $id =  $_GET['id'];
           $sql = "SELECT * FROM student where id=$id";
           $result  = $conn->query($sql);
           $result = $result->fetch_assoc();
           $name = $result['name'];
           $age = $result['age'];
           $marks = $result['marks'];
        }
    ?>
    <h3>update the information:</h3>
    <form action="update_handle.php" method='POST'>
        Name: <input type="text" name='name' value="<?php echo $name?>"><br><br>
        Age: <input type="number" name='age' value="<?php echo $age?>"><br> <br>
        Marks: <input type="number" step="0.1" name='marks' value="<?php echo $marks?>"><br> <br>
        <input type="hidden" name="id" value="<?php echo $id?>">
        <input type="submit">
    </form>
</body>
</html>