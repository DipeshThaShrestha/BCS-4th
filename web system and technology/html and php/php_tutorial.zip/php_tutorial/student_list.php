<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fetch db</title>
    <style>
    table, th, td {
      border: 1px solid black;
     border-collapse: collapse;
    }
    </style>
  </head>
</head>
<body>
    <h3>student information is listed below:</h3>
    <?php
        $server = "localhost";
        $user = "root";
        $pwd = "";
        $db = "sunway";
        $conn = new mysqli($server,$user,$pwd,$db);
        if($conn->connect_error)
        {
            die("connection aborted");
        }
        else
        {
            $sql = "SELECT * FROM student";
            $result = $conn->query($sql);
            // echo var_dump($result->fetch_assoc());
            if($result->num_rows > 0)
            {
                echo "<table>
                <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Marks</th>
                <th colspan='2'>Action</th>
                </tr>";
                while($row = $result->fetch_assoc())
                {
                    echo "<tr>";
                    echo "<td>".$row['id']."</td>";
                    echo "<td>".$row['name']."</td>";
                    echo "<td>".$row['age']."</td>";
                    echo "<td>".$row['marks']."</td>";
                    echo "<td><a href='record_update.php?id=".$row['id']."'>update</a></td>";
                    echo "<td><a href='record_delete.php?id=".$row['id']."'>delete</a></td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        }
    ?>
</body>
</html>