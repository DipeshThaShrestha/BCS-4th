<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h3 style='text-align:center;'>Built in functions for mathematical ops.</h3>
<?php echo pi()."<br>";?>
<?php echo min(10,20,-1,0)."<br>"; ?>
<?php echo abs(-1.25)."<br>"; ?>
<?php echo sqrt(81)."<br>"; ?>

<?php echo round(-1.25)."<br>"; ?>

<?php echo round(0.6)."<br>"; ?>
<?php echo round(0.4)."<br>"; ?>

<?php echo getrandmax()."<br>"; ?>

<?php echo rand()."<br>"; ?>

<?php echo rand(10,20)."<br>"; ?>

</body>
</html>