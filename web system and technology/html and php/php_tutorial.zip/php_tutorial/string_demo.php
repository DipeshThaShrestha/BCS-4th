<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h3 style='text-align:center;'>Learning string and its builtIn functions</h3>
<?php
    $name = "sunway college";
    echo "<p>Total number of character in ".$name." is = ".strlen($name)."</p>";
    $greeting = "Hello how are you";
    echo "<p>Number of word in ".$greeting." is= ".str_word_count($greeting)."<br>";
    $a = "sunway";
    echo "<p> The reverse string of ".$a. " is ".strrev($a)."</p>";
    $s = "my phone number is 9999000";
    echo "pos. of phone number in given text is ".strpos($s,"9999000")."<br>";

    $s = "Hello student of world";
    $s_new = str_replace("world","sunway",$s);

    echo $s_new;


    
?>
</body>
</html>