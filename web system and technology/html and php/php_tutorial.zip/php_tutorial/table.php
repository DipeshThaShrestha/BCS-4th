<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        $num = $_POST['num'];
        echo "<p> Multiplication table of: ".$num." is as below </p>";
        for($i=1;$i<11;$i++)
        {
            echo $num.' X '.$i." = ".$num*$i."<br>";
        }
    }
    ?>
<form action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
<p>Enter a number:</p>
<input type="number" name="num">
<input type="submit">
</form>
</body>
</html>