<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo "<h1>Learning PHP</h1>";
    echo "<p> Variables in php</p>";
    $name = "sunway";
    $age = 10;
    $weight = 20.45;
    $AGE = 20;
    echo ($name);
    echo "<br>";
    echo($AGE);
    echo "<br>";
    echo ($weight);
    echo "<br>";
    echo "Hello my name is: ".$name." Age: ".$age." weight= ".$weight."<br>";

    echo "<h4> data types in PHP: </h4>";
    $college = "sunway college";
    echo $college."<br>";
    echo var_dump($college)."<br>";
    $student_count=100;
    echo var_dump($student_count)."<br>";
    $weight=20.45;
    echo var_dump($weight)."<br>";

    $x = true;
    $y = false;
    echo var_dump($x)." ". var_dump($y)."<br>";

    $car_brand = array("bmw","tesla","toyota","Honda");
    echo var_dump($car_brand)."<br>";
    echo $car_brand[0]."<br>";
    echo "<p> Object variable in PHP</p>";
    class Person{
        public $name;
        public $salary;
        public function __construct($name,$salary){
            $this->name = $name;
            $this->salary = $salary;
        }
        public function display()
        {
            echo "Name: ".$this->name." salary: ".$this->salary."<br>";
        }

    }
    $p = new Person("Ram",1000);
    $p->display();
    echo var_dump($p)."<br>";

    $x = 10.25;
    echo "x is " . var_dump($x)."<br>";
    $x = null;
    // echo var_dump($x)."<br>";

    ?>

</body>
</html>